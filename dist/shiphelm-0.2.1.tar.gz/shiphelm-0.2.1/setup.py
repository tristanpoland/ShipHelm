from setuptools import setup, find_packages

setup(
    name='shiphelm',
    version='0.2.1',
    author='Gameplex Software',
    author_email='info@gameplexsoftware.com',
    description='A Python library built for the SkiffUI project used for interacting with Docker containers more easily',
    url='https://github.com/gameplex-software/shiphelm',
    packages=find_packages(),
    install_requires=['docker'],
)
